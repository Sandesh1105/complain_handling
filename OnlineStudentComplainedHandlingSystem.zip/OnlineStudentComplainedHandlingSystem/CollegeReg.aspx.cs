﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class CollegeReg : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.ClgSubmit(txtCollegeName.Text, txtCollegeCode.Text, txtPrincipalName.Text, txtEmail.Text, txtNumber.Text, txtPass.Text, txtDate.Text);
                        
            Response.Write("<script language='JavaScript'>alert('Inserted Sucessfully..!');</script>");
            Session["College_Name"] = txtCollegeName.Text;
            Session["College_Code"] = txtCollegeCode.Text;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("CollegeLogin.aspx");
        }
    }
}
