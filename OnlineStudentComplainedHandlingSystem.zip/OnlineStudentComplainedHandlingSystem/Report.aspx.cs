﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class Report : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                display();
            }
        }
        public void display()
        {
            //MyClass c = new MyClass();
            //c.Branch((string)Session["College_Code"]);

            //ddlDept.DataSource = c.dr;
            //ddlDept.DataTextField = "Department_Name";
            //ddlDept.DataBind();

            //ddlDept.Items.Insert(0, "Select");

            //c.dr.Close();
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string query = "select * from DeptDB where Department_Name =@DName";
            cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("DName",(string)Session["Department_Name"]);

            dr = cmd.ExecuteReader();

            ddlDept.DataSource = dr;
            ddlDept.DataTextField = "Department_Name";
            ddlDept.DataBind();
            ddlDept.Items.Insert(0, "Select Department");

            dr.Close();
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                MyClass c = new MyClass();
                c.ReportFind((string)Session["College_Name"], ddlDept.SelectedValue);

                GridView1.DataSource = c.dr;
                GridView1.DataBind();

                c.dr.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }

        protected void btnFindAll_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.ReportFindAll((string)Session["College_Name"]);

            GridView1.DataSource = c.dr;
            GridView1.DataBind();

            c.dr.Close();
        }
    }
}