﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class StudentComplaint : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtSName.Text = (string)Session["SName"];
                txtCName.Text = (string)Session["CName"];
                txtBranch.Text = (string)Session["Branch"];
                txtEmail.Text = (string)Session["email"];
                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                MyClass c = new MyClass();
                c.ComplaintSubmit(txtCName.Text, txtSName.Text, txtEmail.Text, txtBranch.Text, ddlComplaint.SelectedValue, txtMessage.Text, txtDate.Text);

                Response.Write("<script language='JavaScript'>alert('Inserted Suceessfully..!');</script>");
                Session["Clg_Name"] = txtCName.Text;
            }
            catch(Exception ex)
            {
                Response.Write(ex);
            }
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.ComplaintShow(txtEmail.Text);            

            GridView1.DataSource = c.dr;
            GridView1.DataBind();

            c.dr.Close();
        }

        protected void btnDelete1_Click(object sender, EventArgs e)
        {
            GridViewRow g = ((Button)sender).NamingContainer as GridViewRow;

            TextBox txtMsg = (TextBox)g.FindControl("txtMsg1");
            TextBox txtCT = (TextBox)g.FindControl("txtComTo1");

            MyClass c = new MyClass();
            c.ComplaintDelete(txtMessage.Text,ddlComplaint.SelectedValue);

            Response.Write("<script language='JavaScript'>alert('Delete Successfull');</script>");
        }
    }
}