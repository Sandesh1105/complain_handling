﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace OnlineStudentComplainedHandlingSystem
{
    public partial class StudentReg : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                ddlCollege.Items.Add((string)Session["College_Name"]);
                ddlBranch.Items.Add((string)Session["Department_Name"]);

                MyClass c = new MyClass();
                c.clg();

                ddlCollege.DataSource = c.dr;
                ddlCollege.DataTextField = "College_Name";
                ddlCollege.DataBind();

                ddlCollege.Items.Insert(0, "Select College");

                c.dr.Close();
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentLogin.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.StuRegSubmit(ddlCollege.SelectedValue, txtSName.Text, ddlBranch.SelectedValue, txtEmail.Text, txtMobile.Text, txtSem.Text, txtPass.Text, txtDate.Text);

            Session["SName"] = txtSName.Text;
            Session["CName"] = ddlCollege.SelectedValue;
            Session["Branch"] = ddlBranch.Text;
            Session["email"] = txtEmail.Text;
            Response.Write("<script language='JavaScript'>alert('Successfully Submitted');</script>");
        }

        protected void ddlCollege_SelectedIndexChanged(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.Dept(ddlCollege.SelectedValue);

            ddlBranch.DataSource = c.dr;
            ddlBranch.DataTextField = "Department_Name";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, "Select Branch");
            c.dr.Close();
        }
    }
}