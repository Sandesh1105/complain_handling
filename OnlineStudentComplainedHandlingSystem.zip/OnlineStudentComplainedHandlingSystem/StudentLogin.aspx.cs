﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class StudentLogin : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
        }

        protected void btnNewAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentReg.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtStudentEmail.Text == "" || txtPass.Text == "")
                {
                    Response.Write("<script language='JavaScript'>alert('Fill properly..!');</script>");
                }
                else
                {
                    string path = ConfigurationManager.AppSettings["MyDB"];
                    con = new SqlConnection(path);
                    con.Open();

                    string select = "select * from StudentReg where Email = @email and Password = @pass";
                    cmd = new SqlCommand(select, con);
                    cmd.Parameters.AddWithValue("email", txtStudentEmail.Text);
                    cmd.Parameters.AddWithValue("pass", txtPass.Text);

                    dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        Response.Redirect("StudentPanel.aspx");
                    }
                    else
                    {
                        Response.Write("<script language='JavaScript'>alert('Invalid User..!');</script>");
                    }
                    Session["email"] = txtStudentEmail.Text;
                    //if (r == "success")
                    //{
                    //    Session["email"] = txtEId.Text;
                    //    Response.Redirect("studentpanel.aspx");
                    //}
                    //else
                    //{
                    //    Response.Write("<script language='JavaScript'>alert('" + r + "');</script>");
                    //}
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }

            
        }
    }
}