﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class News : System.Web.UI.Page
    {
        //create object
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                txtCName.Text = (string)Session["College_Name"];
                txtCCode.Text = (string)Session["College_Code"];
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                MyClass c = new MyClass();
                c.NewsSave(txtCCode.Text, txtCName.Text, txtNews.Text, txtMessage.Text, txtDate.Text);

                Response.Write("<script language='JavaScript'>alert('Form Successfully Submitted');</script>");
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                MyClass c = new MyClass();
                c.NewsShow(txtCCode.Text);

                GridView1.DataSource = c.dr;
                GridView1.DataBind();

                c.dr.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            GridViewRow g = ((Button)sender).NamingContainer as GridViewRow;

            TextBox tTitle = (TextBox)g.FindControl("txtTitle1");
            TextBox tMsg = (TextBox)g.FindControl("txtMessage");

            MyClass c = new MyClass();
            c.NewsEdit(txtMessage.Text, txtCCode.Text, txtNews.Text);

            Response.Write("<script language='JavaScript'>alert('Updated Sucessfully');</script>");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow g = ((Button)sender).NamingContainer as GridViewRow;

                TextBox tTitle = (TextBox)g.FindControl("txtTitle1");

                MyClass c = new MyClass();
                c.NewsDelete(txtCCode.Text, txtNews.Text);

                Response.Write("<script language='JavaScript'>alert('Delete Successfull');</script>");

            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }
    }
}