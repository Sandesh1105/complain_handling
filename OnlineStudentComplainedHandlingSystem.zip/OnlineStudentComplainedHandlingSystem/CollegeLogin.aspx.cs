﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class CollegeLogin : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                //txtCollegeID.Text = (string)Session["College_Code"];
                //txtPass.Text = (string)Session["Password"];
            }
        }

        protected void btnNewAccount_Click(object sender, EventArgs e)
        {
            Response.Redirect("CollegeReg.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.ClgLogin(txtCollegeID.Text, txtPass.Text);

            Response.Redirect("CollegeAdmin.aspx");

            Response.Write("<script language='JavaScript'>alert('Invalid User and Password');</script>");
            Session["College_Code"] = txtCollegeID.Text;
       }
    }
}