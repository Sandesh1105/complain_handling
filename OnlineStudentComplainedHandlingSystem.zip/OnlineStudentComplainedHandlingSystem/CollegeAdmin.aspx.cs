﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class CollegeAdmin1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                lblClgName.Text = (string)Session["College_Name"];
            }
        }

        protected void btnCreateDept_Click(object sender, EventArgs e)
        {
            Response.Redirect("Departmentt.aspx");
        }

        protected void btnCreateDeptUser_Click(object sender, EventArgs e)
        {
            Response.Redirect("DeptUser.aspx");
        }

        protected void btnReport_Click(object sender, EventArgs e)
        {
            Response.Redirect("Report.aspx");
        }

        protected void btnNews_Click(object sender, EventArgs e)
        {
            Response.Redirect("News.aspx");
        }
    }
}