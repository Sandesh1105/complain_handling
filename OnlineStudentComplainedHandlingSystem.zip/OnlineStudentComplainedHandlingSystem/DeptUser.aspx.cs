﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class DeptUser : System.Web.UI.Page
    {
        //create object
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                txtCollegeName.Text = (string)Session["College_Name"];
                txtCollegeCode.Text = (string)Session["College_Code"];
                //txtCollegeName.Text = Session["College_Name"].ToString();
                //txtCollegeCode.Text = Session["College_Code"].ToString();

                txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string query = "select * from DeptDB where Department_Name = @DName";
                cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("DName", (string)Session["Department_Name"]);

                dr = cmd.ExecuteReader();

                ddlDept.DataSource = dr;
                ddlDept.DataTextField = "Department_Name";
                ddlDept.DataBind();
                ddlDept.Items.Insert(0, "Select Department");

                dr.Close();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.DeptUserSubmit(txtCollegeName.Text, txtCollegeCode.Text, ddlDept.SelectedValue, txtUserFalculty.Text, txtUserID.Text, txtPass.Text, txtDate.Text);

            Session["Dept"] = ddlDept.Text;
            Response.Write("<script language='JavaScript'>alert('Successfully Submitted!');</script>");
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.ShowBranch(txtCollegeName.Text);

            ddlDept2.DataSource = c.dr;
            ddlDept2.DataTextField = "Department_Name";
            ddlDept2.DataBind();
            ddlDept2.Items.Insert(0, "Select");

            ddlDept2.Visible = true;
            btnFind.Visible = true;

            
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            GridViewRow g = ((Button)sender).NamingContainer as GridViewRow;

            TextBox tUser= (TextBox)g.FindControl("txtUserID1");
            TextBox tPass = (TextBox)g.FindControl("txtPass1");
            TextBox tFac = (TextBox)g.FindControl("txtFaculty1");

            MyClass c = new MyClass();
            c.UserDeptEdit(tUser.Text, tPass.Text, tFac.Text, txtCollegeCode.Text, txtCollegeName.Text);

            Response.Write("<script language='JavaScript'>alert('Updated Successfull');</script>");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            GridViewRow g1 = ((Button)sender).NamingContainer as GridViewRow;

            TextBox tUserId = (TextBox)g1.FindControl("txtUserID1");

            MyClass c = new MyClass();
            c.UserDeptDelete(txtCollegeCode.Text,txtCollegeName.Text);

            Response.Write("<script language='JavaScript'>alert('Delete Successfull');</script>");
        }

        protected void ddlDept2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from DeptUserDB where College_Code=@CCode and Department_Name=@Dept";
            cmd = new SqlCommand(select, con);
            cmd.Parameters.AddWithValue("CCode", txtCollegeCode.Text);
            cmd.Parameters.AddWithValue("Dept", ddlDept2.SelectedValue);

            dr = cmd.ExecuteReader();

            GridView1.DataSource = dr;
            GridView1.DataBind();

            dr.Close();
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                MyClass c = new MyClass();
                c.ReportFind((string)Session["College_Code"], (string)Session["Department_Name"]);
                
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
        }
    }
}