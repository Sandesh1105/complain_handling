﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class Departmentt : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                txtCName.Text = (string)Session["College_Name"];
                txtCCode.Text = (string)Session["College_Code"];
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.DeptSubmit(txtCCode.Text, txtCName.Text, txtDept.Text);
            
            Response.Write("<script language='JavaScript'>alert('Form Successfully Submited');</script>");
            Session["College_Name"] = txtCName.Text;
            Session["Department_Name"] = txtDept.Text;
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            MyClass c = new MyClass();
            c.DeptShow(txtCCode.Text);

            GridView1.DataSource = c.dr;
            GridView1.DataBind();

            c.dr.Close();
            btnDelete.Visible = true;
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow r1 in GridView1.Rows)
            {
                CheckBox c = (CheckBox)r1.FindControl("chkBoxAction");
                TextBox tDept = (TextBox)r1.FindControl("txtDept1");

                if (c.Checked)
                {
                    string path = ConfigurationManager.AppSettings["MyDB"];
                    con = new SqlConnection(path);
                    con.Open();

                    string delete = "DELETE FROM DeptDB where College_Code=@College_Code1 and Department_Name=@DeptName1";
                    cmd = new SqlCommand(delete, con);

                    cmd.Parameters.AddWithValue("College_Code1", txtCCode.Text);
                    cmd.Parameters.AddWithValue("DeptName1", txtDept.Text);

                    cmd.ExecuteNonQuery();
                }
                Response.Write("<script language='JavaScript'>alert('Delete Successfully');</script>");
            }
        }
    }
}