﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineStudentComplainedHandlingSystem
{
    public partial class StudentPanel1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblEmail.Text = (string)Session["email"];
        }

        protected void btnComplaintForm_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentComplaint.aspx");
        }

        protected void btnComplaintStatus_Click(object sender, EventArgs e)
        {
            Response.Redirect("Status.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("CollegeReg.aspx");
        }
    }
}