﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace OnlineStudentComplainedHandlingSystem
{
    public class MyClass
    {
        SqlConnection con;
        SqlCommand cmd;
        public SqlDataReader dr;
        public string ClgSubmit(string CName, string CC, string PName, string Email, string Mobile, string Password, string Date)
        {
            if (CName == "" || CC == "" || PName == "" || Email == "" || Mobile == "" || Password == "" || Date == "")
            {
                return "Fill properly..!";
            }
            else
            {
                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string query = "select * from CollegeRegDB where College_Code = @CCode";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("CCode", CC);

                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return "Already Registered college Code!";
                }
                else
                {
                    dr.Close();

                    string insert = "insert into CollegeRegDB(College_Name,College_Code,Principal_Name,Email_Id,Mobile,Password) values (@College_Name1,@College_Code1,@Principal_Name1,@Email_Id1,@Mobile1,@Password1)";
                    cmd = new SqlCommand(insert, con);
                    cmd.Parameters.AddWithValue("College_Name1", CName);
                    cmd.Parameters.AddWithValue("College_Code1", CC);
                    cmd.Parameters.AddWithValue("Principal_Name1", PName);
                    cmd.Parameters.AddWithValue("Email_Id1", Email);
                    cmd.Parameters.AddWithValue("Mobile1", Mobile);
                    cmd.Parameters.AddWithValue("Password1", Password);
                    //cmd.Parameters.AddWithValue("Date1", txtDate.Text);

                    //Execute query
                    cmd.ExecuteReader();

                    return "Submitted Successfully";
                }
            }
        }
        public void ClgLogin(string CID, string Pass)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from CollegeRegDB where College_Code =@College_Code1 and Password=@Pass1";
            cmd = new SqlCommand(select, con);
            cmd.Parameters.AddWithValue("College_code1", CID);
            cmd.Parameters.AddWithValue("Pass1", Pass);

            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                return;
            }
        }
        public string DeptSubmit(string CCode, string CName, string Dept)
        {
            if (CCode == "" || CName == "" || Dept == "")
            {
                return "Fill peoperly..!";
            }
            else
            {
                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string select = "select * from DeptDB where College_Name = @CName and College_Code=@CCode and Department_Name=@Dept1";
                cmd = new SqlCommand(select, con);
                cmd.Parameters.AddWithValue("CName", CName);
                cmd.Parameters.AddWithValue("CCode", CCode);
                cmd.Parameters.AddWithValue("Dept1", Dept);

                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return "Already inserted...!";
                }
                else
                {
                    dr.Close();

                    string insert = "insert into DeptDB(College_Name,College_Code,Department_Name) values (@College_Name1,@College_Code1,@Department_Name1)";
                    cmd = new SqlCommand(insert, con);
                    cmd.Parameters.AddWithValue("College_Name1", CName);
                    cmd.Parameters.AddWithValue("College_Code1", CCode);
                    cmd.Parameters.AddWithValue("Department_Name1", Dept);

                    cmd.ExecuteReader();

                    return "Inserted Successfully..!";
                }
            }
        }
        public void DeptShow(string CCode)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from DeptDB where College_Code=@College_Code1";
            cmd = new SqlCommand(select, con);
            cmd.Parameters.AddWithValue("College_Code1", CCode);

            dr = cmd.ExecuteReader();
        }
        public string DeptUserSubmit(string CName, string CCode, string Dept, string Fac, string User, string Pass, string Date)
        {
            if (CName == "" || CCode == "" || Dept == "Select" || Fac == "" || User == "" || Pass == "" || Date == "")
            {
                return "Fill properly";
            }
            else
            {
                //connnection
                string path = ConfigurationManager.AppSettings["MyDb"];
                con = new SqlConnection(path);
                con.Open();

                string select = "select * from DeptUserDB where College_Code = @CCode and User_ID = @UserId1";
                cmd = new SqlCommand(select, con);
                cmd.Parameters.AddWithValue("CCode", CCode);
                cmd.Parameters.AddWithValue("UserId1", User);

                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return "Already Exist..!";
                }
                else
                {
                    dr.Close();
                    //apply command
                    string insert = "INSERT INTO DeptUserDB(College_Name,College_Code,Department_Name,Faculty_Name,User_ID,Password,Date) VALUES(@College_Name1,@College_Code1,@Department1,@Falculty_Name1,@User_ID1,@Password1,@Date1)";
                    cmd = new SqlCommand(insert, con);
                    ////com.Parameters.AddWithValue("Sno", txtID.Text);
                    cmd.Parameters.AddWithValue("College_Name1", CName);
                    cmd.Parameters.AddWithValue("College_Code1",CCode);
                    cmd.Parameters.AddWithValue("Department1", Dept);
                    cmd.Parameters.AddWithValue("Falculty_Name1", Fac);
                    cmd.Parameters.AddWithValue("User_ID1", User);
                    cmd.Parameters.AddWithValue("Password1", Pass);
                    cmd.Parameters.AddWithValue("Date1", Date);

                    cmd.ExecuteReader();

                    return "Inserted Successfully..!";
                }
            }
        }
        public void ShowBranch(string CName)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string query = "select Department_Name from DeptDB where College_Name = @CName";
            cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("CName", CName);

            dr = cmd.ExecuteReader();
        }
        public void UserDeptEdit(string User,string pass,string Fac,string CCode, string CName)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string update = "UPDATE DeptUserDB SET User_ID=@UserID, Password=@Pass, Faculty_Name=@Falculty WHERE College_Code=@CCode and College_Name=@CName";
            cmd = new SqlCommand(update, con);

            cmd.Parameters.AddWithValue("UserId", User);
            cmd.Parameters.AddWithValue("Pass", pass);
            cmd.Parameters.AddWithValue("Falculty", Fac);
            cmd.Parameters.AddWithValue("CCode", CCode);
            cmd.Parameters.AddWithValue("CName", CName);

            cmd.ExecuteNonQuery();
        }
        public void UserDeptDelete(string CCode,string CName)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string delete = "DELETE FROM DeptUserDB WHERE College_Code=@CCode and College_Name=@CName";
            cmd = new SqlCommand(delete, con);

            cmd.Parameters.AddWithValue("CCode", CCode);
            cmd.Parameters.AddWithValue("CName", CName);

            cmd.ExecuteNonQuery();
        }
        public void Branch(string CCode)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string query = "select Department_Name from DeptDB where College_Code = @CCode";
            cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("CCode", CCode);
            
            dr = cmd.ExecuteReader();
        }
        public void ReportFind(string Clg,string dept)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from StudentComplaint where College_Name =@clg1 and Branch = @Branch1";
            cmd = new SqlCommand(select, con);

            cmd.Parameters.AddWithValue("clg1", Clg);
            cmd.Parameters.AddWithValue("Branch1", dept);

            dr = cmd.ExecuteReader();
        }
        public void ReportFindAll(string Clg)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from StudentComplaint where College_Name =@clg";
            cmd = new SqlCommand(select, con);

            cmd.Parameters.AddWithValue("clg", Clg);
            //cmd.Parameters.AddWithValue("Branch1", Branch);

            dr = cmd.ExecuteReader();
        }
        public string NewsSave(string CCode,string CName,string News,string Message,string Date)
        {
            if (CCode == "" || CName== "" || News == "" || Message == "" || Date == "")
            {
                return "Fill Properly";
            }
            else
            {
                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string select = "select * from NewsDB where College_Code=@CCode and News_Title=@NTitle";
                cmd = new SqlCommand(select, con);

                cmd.Parameters.AddWithValue("CCode", CCode);
                cmd.Parameters.AddWithValue("NTitle", CName);

                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return "Already inserted..!";
                }
                else
                {
                    dr.Close();

                    string insert = "insert into NewsDB values (@College_Code1,@College_Name1,@News_Title1,@Message1,@Date1)";
                    cmd = new SqlCommand(insert, con);

                    cmd.Parameters.AddWithValue("College_Code1", CCode);
                    cmd.Parameters.AddWithValue("College_Name1",CName);
                    cmd.Parameters.AddWithValue("News_Title1", News);
                    cmd.Parameters.AddWithValue("Message1", Message);
                    cmd.Parameters.AddWithValue("Date1", Date);

                    cmd.ExecuteReader();
                    return "Seved..!";
                }
            }
        }
        public void NewsShow(string CCode)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from NewsDB where College_Code=@CCode1";
            cmd = new SqlCommand(select, con);
            cmd.Parameters.AddWithValue("CCode1", CCode);

            dr = cmd.ExecuteReader();
        }
        public void NewsDelete(string CCode,string News)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string delete = "DELETE FROM NewsDB where College_Code = @CCode and News_Title = @NTitle";
            cmd = new SqlCommand(delete, con);

            cmd.Parameters.AddWithValue("CCode", CCode);
            cmd.Parameters.AddWithValue("NTitle", News);

            cmd.ExecuteNonQuery();
        }
        public void NewsEdit(string msg,string CCode,string title)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();


            string update = "UPDATE NewsDB SET Message=@msg where College_Code = @CCode and News_Title = @NTitle";
            cmd = new SqlCommand(update, con);

            cmd.Parameters.AddWithValue("msg", msg);
            cmd.Parameters.AddWithValue("CCode", CCode);
            cmd.Parameters.AddWithValue("NTitle", title);

            cmd.ExecuteNonQuery();
        }
        public string ComplaintSubmit(string CName, string SName, string Email, string Branch, string Compt, string Msg, string Date)
        {
            if (SName == "" || CName == "" || Email == "" || Branch == "" || Compt == "Select" || Msg == "" || Date == "")
            {
                return "Fill Properly..!";
            }
            else
            {
                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string insert = "INSERT INTO StudentComplaint(College_Name,Student_Name,Email_ID,Branch,Complaint_To,Message,Date) Values (@CName1,@SName1,@Email1,@Branch1,@ComTo1,@msg1,@Date1)";
                cmd = new SqlCommand(insert, con);

                cmd.Parameters.AddWithValue("CName1", CName);
                cmd.Parameters.AddWithValue("Sname1", SName);
                cmd.Parameters.AddWithValue("Email1", Email);
                cmd.Parameters.AddWithValue("Branch1", Branch);
                cmd.Parameters.AddWithValue("ComTo1", Compt);
                cmd.Parameters.AddWithValue("msg1", Msg);
                cmd.Parameters.AddWithValue("Date1", Date);

                cmd.ExecuteReader();
                return "Saved..!";
            }
        }
        public void ComplaintShow(string Email)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select * from StudentComplaint where Email_ID =@email1";
            cmd = new SqlCommand(select, con);

            cmd.Parameters.AddWithValue("email1", Email);

            dr = cmd.ExecuteReader();
        }
        public void ComplaintDelete(string Msg,string Comt)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string delete = "DELETE FROM StudentComplaint WHERE Message = @msg1 and Complaint_To = @ComTo1";
            cmd = new SqlCommand(delete, con);

            cmd.Parameters.AddWithValue("msg1", Msg);
            cmd.Parameters.AddWithValue("ComTo1", Comt);

            cmd.ExecuteNonQuery();
        }
        public string StuRegSubmit(string Clg, string SName, string Branch, string Email, string Mobile, string Sem, string Pass, string Date)
        {
            if (Clg == "Select" || SName == "" || Branch == "Select" || Email == "" || Mobile == "" || Sem == "" || Pass == "" || Date == "")
            {
                return "Fill properly..!";
            }
            else
            {
                string path = ConfigurationManager.AppSettings["MyDB"];
                con = new SqlConnection(path);
                con.Open();

                string select = "select * from StudentReg where Email = @Email1";
                cmd = new SqlCommand(select, con);
                cmd.Parameters.AddWithValue("Email1", Email);

                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return "'Already Exist..!";
                }
                else
                {
                    dr.Close();

                    string insert = "insert into StudentReg(College,Student_Name,Branch,Email,Mobile,Semister,Password,Date) values (@College1,@Student_Name1,@Branch1,@Email1,@Mobile1,@Semister1,@Password1,@Date1)";
                    cmd = new SqlCommand(insert, con);
                    cmd.Parameters.AddWithValue("College1", Clg);
                    cmd.Parameters.AddWithValue("Student_Name1", SName);
                    cmd.Parameters.AddWithValue("Branch1", Branch);
                    cmd.Parameters.AddWithValue("Email1", Email);
                    cmd.Parameters.AddWithValue("Mobile1", Mobile);
                    cmd.Parameters.AddWithValue("Semister1", Sem);
                    cmd.Parameters.AddWithValue("Password1", Pass);
                    cmd.Parameters.AddWithValue("Date1", Date);

                    //Execute query
                    dr = cmd.ExecuteReader();

                    return "Saved..!";
                }
            }
        }
        public void clg()
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string select = "select College_Name from CollegeRegDB";
            cmd = new SqlCommand(select, con);

            dr = cmd.ExecuteReader();
        }
        public void Dept(string CCoode)
        {
            string path = ConfigurationManager.AppSettings["MyDB"];
            con = new SqlConnection(path);
            con.Open();

            string query = "select Department_Name from DeptDB where College_Name = @CName";
            cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("CName", CCoode);

            dr = cmd.ExecuteReader();
        }
    }
}


